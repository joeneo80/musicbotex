Go to https://github.com/joeneo80/musicbotex/ for more info!!
-JoeNeo80